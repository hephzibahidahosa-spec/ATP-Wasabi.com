import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BMp9hPkk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var BASE_SPW = {
	"hard-indoor": .632,
	"hard-outdoor": .62,
	clay: .598
};
function clamp(n, lo, hi) {
	return Math.min(hi, Math.max(lo, n));
}
function playerRating(p) {
	if (p.rank == null || p.rank < 1) return null;
	return 1580 - 96 * Math.log(p.rank) + clamp(p.fit * 12 + p.form * 8 + p.serve * 4 + (p.home ? 10 : 0) + (p.leaky ? -6 : 0) + (p.live ? 4 : 0), -28, 22);
}
function gapScale(category) {
	if (category === 50) return .78;
	if (category === 75) return .9;
	return 1;
}
function servePoints(server, returner, surface, category) {
	const rs = playerRating(server);
	const rr = playerRating(returner);
	if (rs == null || rr == null) return null;
	const diff = (rs - rr) / 100 * gapScale(category);
	let spw = BASE_SPW[surface] + .042 * diff;
	spw += .008 * server.serve;
	spw -= .004 * returner.serve;
	if (server.leaky) spw -= .006;
	if (returner.live) spw -= .004;
	return clamp(spw, .5, .74);
}
/** P(server wins a game) under advantage scoring. */
function gameWinProb(p) {
	const q = 1 - p;
	const deuce = p * p / (p * p + q * q);
	return p ** 4 * (1 + 4 * q + 10 * q * q) + 20 * p ** 3 * q ** 3 * deuce;
}
function tbServerIsA(pointIndex, aStarts) {
	let aServes;
	if (pointIndex === 0) aServes = true;
	else aServes = Math.floor((pointIndex - 1) / 2) % 2 === 1;
	return aStarts ? aServes : !aServes;
}
/** P(A wins a tiebreak), first to 7 win by 2. Deterministic DP. */
function tiebreakWin(spwA, spwB, aStarts) {
	const MAX = 24;
	const dp = Array.from({ length: 25 }, () => Array(25).fill(0));
	for (let a = MAX; a >= 0; a--) for (let b = MAX; b >= 0; b--) {
		if (a >= 7 && a >= b + 2) {
			dp[a][b] = 1;
			continue;
		}
		if (b >= 7 && b >= a + 2) {
			dp[a][b] = 0;
			continue;
		}
		if (a === MAX || b === MAX) {
			dp[a][b] = a === b ? .5 : a > b ? .85 : .15;
			continue;
		}
		const p = tbServerIsA(a + b, aStarts) ? spwA : 1 - spwB;
		dp[a][b] = p * dp[a + 1][b] + (1 - p) * dp[a][b + 1];
	}
	return dp[0][0];
}
/** P(A wins a set), averaging who serves first. */
function setWinProb(spwA, spwB) {
	const holdA = gameWinProb(spwA);
	const breakA = 1 - gameWinProb(spwB);
	const once = (aServesFirst) => {
		const memo = /* @__PURE__ */ new Map();
		const p = (a, b) => {
			const key = `${a}-${b}`;
			const hit = memo.get(key);
			if (hit != null) return hit;
			let val;
			if (a >= 6 && a - b >= 2) val = 1;
			else if (b >= 6 && b - a >= 2) val = 0;
			else if (a === 6 && b === 6) val = tiebreakWin(spwA, spwB, aServesFirst);
			else {
				const winGame = (aServesFirst ? (a + b) % 2 === 0 : (a + b) % 2 === 1) ? holdA : breakA;
				val = winGame * p(a + 1, b) + (1 - winGame) * p(a, b + 1);
			}
			memo.set(key, val);
			return val;
		};
		return p(0, 0);
	};
	return .5 * (once(true) + once(false));
}
function scoreMatch(spwA, spwB) {
	const s = setWinProb(spwA, spwB);
	const a20 = s * s;
	const a21 = 2 * s * s * (1 - s);
	return {
		a20,
		a21,
		b21: 2 * (1 - s) * (1 - s) * s,
		b02: (1 - s) * (1 - s),
		setA: s,
		matchA: a20 + a21
	};
}
function price(match) {
	const spwA = servePoints(match.a, match.b, match.surface, match.category);
	const spwB = servePoints(match.b, match.a, match.surface, match.category);
	if (spwA == null || spwB == null) return null;
	return {
		...scoreMatch(spwA, spwB),
		spwA,
		spwB,
		holdA: gameWinProb(spwA),
		holdB: gameWinProb(spwB)
	};
}
function pct$1(n) {
	return `${Math.round(n * 100)}%`;
}
function surfaceLabel(s) {
	if (s === "hard-indoor") return "indoor hard";
	if (s === "hard-outdoor") return "outdoor hard";
	return "clay";
}
function decide(match, line) {
	if (line == null || match.a.rank == null || match.b.rank == null) return {
		kind: "pass",
		pick: null,
		score: null,
		confidence: 0,
		reason: "One player is off the published ATP ranking list, so the price is not a ticket.",
		bullets: ["No invented rank is used to manufacture a favourite.", "Straight-sets and set tickets both stay blank."]
	};
	const fav = line.matchA >= .5 ? "a" : "b";
	const dog = fav === "a" ? "b" : "a";
	const favP = fav === "a" ? match.a : match.b;
	const dogP = dog === "a" ? match.a : match.b;
	const setFav = fav === "a" ? line.setA : 1 - line.setA;
	const matchFav = setFav * setFav * (3 - 2 * setFav);
	const p20 = setFav * setFav;
	const p21 = 2 * setFav * setFav * (1 - setFav);
	const dogSet = 1 - setFav;
	const dogAtLeast = 1 - p20;
	const lowLevel = match.category === 50;
	const p20Cut = lowLevel ? .5 : .47;
	const matchCut = lowLevel ? .76 : .72;
	const marginCut = .1;
	const rankGapOk = (dogP.rank != null && favP.rank != null ? dogP.rank / favP.rank : 1) >= 1.85;
	const blocks = [];
	if (favP.leaky) blocks.push(`${favP.name.split(" ").slice(-1)[0]} has been extended to three`);
	if (dogP.live) blocks.push(`${dogP.name.split(" ").slice(-1)[0]} takes sets off better players`);
	if (dogP.serve >= 2) blocks.push(`${dogP.name.split(" ").slice(-1)[0]} has a serve that steals sets`);
	if (dogP.form >= 2) blocks.push(`${dogP.name.split(" ").slice(-1)[0]} is in the kind of form that makes 2–0 fragile`);
	const pure = blocks.length === 0 && rankGapOk && matchFav >= matchCut && p20 >= p20Cut && p20 >= p21 + marginCut;
	const last = (p) => p.name.split(" ").slice(-1)[0] ?? p.name;
	const shared = [`${last(match.a)} No. ${match.a.rank} vs ${last(match.b)} No. ${match.b.rank} on ${surfaceLabel(match.surface)}.`, `Serve points ${pct$1(line.spwA)} / ${pct$1(line.spwB)}. Holds ${pct$1(line.holdA)} / ${pct$1(line.holdB)}. Set ${pct$1(line.setA)} for ${last(match.a)}.`];
	if (pure) return {
		kind: "straight",
		pick: fav,
		score: "2-0",
		confidence: p20,
		reason: `${favP.name} is a pure favourite. The only score printed is 2–0.`,
		bullets: [
			...shared,
			`Match ${pct$1(matchFav)}, straight sets ${pct$1(p20)} against ${pct$1(p21)} for 2–1. Gap clears the ${match.category === 50 ? "Challenger 50" : "Challenger"} bar.`,
			match.context[0] ?? "No extra veto from form, serve or a live underdog."
		]
	};
	const setOk = matchFav >= .63 && matchFav < .76 && dogAtLeast >= .55 && dogSet >= .38 && p21 + .02 >= p20 * .45;
	const vetoRedirect = blocks.length > 0 && matchFav >= .6 && matchFav <= .84 && dogAtLeast >= .48 && dogSet >= .27;
	if (setOk || vetoRedirect) return {
		kind: "set",
		pick: dog,
		score: "2-1",
		confidence: dogAtLeast,
		reason: `${dogP.name} to win at least one set. The match is scripted 2–1, not a straight-sets favourite.`,
		bullets: [
			...shared,
			`${last(favP)} is favoured at ${pct$1(matchFav)} but straight sets is only ${pct$1(p20)} — not pure. ${last(dogP)} wins a set ${pct$1(dogAtLeast)} of the time.`,
			blocks[0] ?? match.context[0] ?? "Close enough that a stolen set is the price, and the match still has a winner."
		]
	};
	let reason = "No ticket. Neither a pure 2–0 favourite nor a live 2–1 set.";
	if (matchFav < .6) reason = "Toss-up. No favourite is pure, and a 2–1 script needs a side.";
	else if (!rankGapOk && blocks.length === 0 && p20 >= p20Cut && matchFav >= matchCut) reason = "The score leans 2–0, but the ranking gap is too short to call anyone a pure favourite.";
	else if (blocks.length && p20 >= p20Cut) reason = `Straight sets is the lean, but it is not pure: ${blocks[0]}. The underdog's set price is still too thin to buy.`;
	else if (dogAtLeast < .56) reason = "The underdog is not live enough to buy a set, and the favourite is not pure enough for 2–0.";
	return {
		kind: "pass",
		pick: null,
		score: null,
		confidence: 0,
		reason,
		bullets: [...shared, blocks[0] ?? "Left on the board."]
	};
}
/** Quarter-finals, Friday 13 November 2026.
* Draws: ATP Challenger (atptour.com) and the tour record.
* Order of play: Flashscore / SofaScore where a local time was published.
* Ranks: ATP singles, week of 9 November 2026.
*/
var BOARD = [
	{
		id: "orl-piros-altmaier",
		event: "Co'met Orléans Open",
		place: "Orléans",
		category: 125,
		surface: "hard-indoor",
		round: "Quarter-final",
		when: "13:00",
		a: {
			name: "Zsombor Piros",
			country: "HUN",
			rank: 99,
			tag: "7",
			serve: 0,
			fit: 1,
			form: 1,
			leaky: true
		},
		b: {
			name: "Daniel Altmaier",
			country: "GER",
			rank: 73,
			tag: "2",
			serve: 0,
			fit: -1,
			form: 0,
			leaky: true
		},
		context: ["Both already went three sets this week. Altmaier is the higher rank and a clay lean indoors."]
	},
	{
		id: "orl-gentzsch-basavareddy",
		event: "Co'met Orléans Open",
		place: "Orléans",
		category: 125,
		surface: "hard-indoor",
		round: "Quarter-final",
		when: "14:30",
		a: {
			name: "Tom Gentzsch",
			country: "LUX",
			rank: 159,
			serve: 0,
			fit: 1,
			form: 2,
			live: true
		},
		b: {
			name: "Nishesh Basavareddy",
			country: "USA",
			rank: 126,
			serve: 1,
			fit: 2,
			form: 1,
			leaky: true
		},
		context: ["Gentzsch beat Bonzi in straights. Basavareddy dropped a set to Jacquet after a straight-sets win over Herbert."]
	},
	{
		id: "orl-hemery-martinez",
		event: "Co'met Orléans Open",
		place: "Orléans",
		category: 125,
		surface: "hard-indoor",
		round: "Quarter-final",
		when: "16:00",
		a: {
			name: "Calvin Hemery",
			country: "FRA",
			rank: 284,
			tag: "Q",
			serve: 0,
			fit: 1,
			form: 2,
			home: true,
			live: true
		},
		b: {
			name: "Pedro Martinez",
			country: "ESP",
			rank: 124,
			serve: 0,
			fit: -1,
			form: 1,
			leaky: true
		},
		context: ["Hemery, at home, beat Baez 6–4 7–5. Martinez beat Martineau 6–3 6–2 and Rodionov in three."]
	},
	{
		id: "orl-sgw-virtanen",
		event: "Co'met Orléans Open",
		place: "Orléans",
		category: 125,
		surface: "hard-indoor",
		round: "Quarter-final",
		when: "19:00",
		a: {
			name: "Sascha Gueymard Wayenburg",
			country: "FRA",
			rank: 202,
			tag: "WC",
			serve: 0,
			fit: 1,
			form: 2,
			home: true,
			live: true,
			leaky: true
		},
		b: {
			name: "Otto Virtanen",
			country: "FIN",
			rank: 127,
			serve: 2,
			fit: 2,
			form: 1,
			leaky: true
		},
		context: ["Virtanen leads the head-to-head 6–2 6–4 (Helsinki 2025) and beat Svrčina in straights. Gueymard Wayenburg took out Bellucci in three."]
	},
	{
		id: "knx-shelbayh-gray",
		event: "Knoxville Challenger",
		place: "Knoxville",
		category: 75,
		surface: "hard-indoor",
		round: "Quarter-final",
		a: {
			name: "Abedallah Shelbayh",
			country: "JOR",
			rank: 305,
			serve: 0,
			fit: 1,
			form: 1
		},
		b: {
			name: "Alastair Gray",
			country: "GBR",
			rank: 270,
			serve: 1,
			fit: 1,
			form: 0
		},
		context: ["Tight ranking band on a quick indoor hard court. Neither profile is a closer."]
	},
	{
		id: "knx-rehberg-milavsky",
		event: "Knoxville Challenger",
		place: "Knoxville",
		category: 75,
		surface: "hard-indoor",
		round: "Quarter-final",
		a: {
			name: "Max Hans Rehberg",
			country: "GER",
			rank: 241,
			serve: 0,
			fit: 1,
			form: 1
		},
		b: {
			name: "Daniel Milavsky",
			country: "USA",
			rank: 310,
			serve: 0,
			fit: 1,
			form: 0,
			home: true
		},
		context: ["Rehberg holds the ranking edge. Milavsky is the home player and a modest one."]
	},
	{
		id: "knx-draxl-chidekh",
		event: "Knoxville Challenger",
		place: "Knoxville",
		category: 75,
		surface: "hard-indoor",
		round: "Quarter-final",
		a: {
			name: "Liam Draxl",
			country: "CAN",
			rank: 165,
			serve: 0,
			fit: 1,
			form: 1
		},
		b: {
			name: "Clément Chidekh",
			country: "FRA",
			rank: 129,
			serve: 0,
			fit: 1,
			form: 0
		},
		context: ["Draxl beat Nesterov 6–3 6–3. Chidekh is the higher rank after a Charlottesville semi."]
	},
	{
		id: "knx-kozlov-zheng",
		event: "Knoxville Challenger",
		place: "Knoxville",
		category: 75,
		surface: "hard-indoor",
		round: "Quarter-final",
		a: {
			name: "Stefan Kozlov",
			country: "USA",
			rank: 205,
			serve: 1,
			fit: 1,
			form: 2,
			home: true,
			live: true
		},
		b: {
			name: "Michael Zheng",
			country: "USA",
			rank: 100,
			serve: 0,
			fit: 1,
			form: 0
		},
		context: ["Zheng is the top-100 player. Kozlov won Charlottesville last week, the final in three sets."]
	},
	{
		id: "lim-magadan-roncadelli",
		event: "Lima Challenger",
		place: "Lima",
		category: 75,
		surface: "clay",
		round: "Quarter-final",
		a: {
			name: "Alan Magadán",
			country: "MEX",
			rank: 491,
			serve: -1,
			fit: 0,
			form: 0
		},
		b: {
			name: "Franco Roncadelli",
			country: "URU",
			rank: 258,
			serve: 0,
			fit: 1,
			form: 1
		},
		context: ["Clay, and a wide ranking gap. Roncadelli is the South American clay player in the pair."]
	},
	{
		id: "lim-boyer-alcala",
		event: "Lima Challenger",
		place: "Lima",
		category: 75,
		surface: "clay",
		round: "Quarter-final",
		a: {
			name: "Tristan Boyer",
			country: "USA",
			rank: 208,
			serve: 1,
			fit: -1,
			form: 0,
			live: true
		},
		b: {
			name: "Max Alcalá Gurri",
			country: "ESP",
			rank: 131,
			serve: 0,
			fit: 2,
			form: 1
		},
		context: ["Alcalá Gurri is the clay profile and the higher rank. Boyer's serve is the set threat."]
	},
	{
		id: "lim-olivieri-reis",
		event: "Lima Challenger",
		place: "Lima",
		category: 75,
		surface: "clay",
		round: "Quarter-final",
		a: {
			name: "Genaro Alberto Olivieri",
			country: "ARG",
			rank: 244,
			serve: 0,
			fit: 2,
			form: 1,
			leaky: true
		},
		b: {
			name: "João Lucas Reis da Silva",
			country: "BRA",
			rank: 190,
			serve: 0,
			fit: 2,
			form: 0
		},
		context: ["Olivieri lost the Villa María final last week. Reis da Silva is slightly higher and on clay at home in the region."]
	},
	{
		id: "lim-sanchez-tobon",
		event: "Lima Challenger",
		place: "Lima",
		category: 75,
		surface: "clay",
		round: "Quarter-final",
		a: {
			name: "Nikolas Sánchez Izquierdo",
			country: "ESP",
			rank: 151,
			serve: 0,
			fit: 2,
			form: 0
		},
		b: {
			name: "Miguel Tobón",
			country: "COL",
			rank: null,
			tag: "WC",
			serve: 0,
			fit: 1,
			form: 0,
			home: true
		},
		context: ["Tobón is not on the published ATP singles list used for this board. No rank is invented."]
	},
	{
		id: "mat-sakamoto-milic",
		event: "Ehime International",
		place: "Matsuyama",
		category: 75,
		surface: "hard-outdoor",
		round: "Quarter-final",
		a: {
			name: "Rei Sakamoto",
			country: "JPN",
			rank: 122,
			serve: 0,
			fit: 2,
			form: 1,
			home: true
		},
		b: {
			name: "Ognjen Milić",
			country: "SRB",
			rank: 392,
			serve: 0,
			fit: 0,
			form: 0
		},
		context: ["Sakamoto is at home, inside the top 125, against a player outside the top 390."]
	},
	{
		id: "mat-uchida-harris",
		event: "Ehime International",
		place: "Matsuyama",
		category: 75,
		surface: "hard-outdoor",
		round: "Quarter-final",
		a: {
			name: "Kaichi Uchida",
			country: "JPN",
			rank: 431,
			serve: 0,
			fit: 1,
			form: 1,
			home: true
		},
		b: {
			name: "Billy Harris",
			country: "GBR",
			rank: 227,
			serve: 1,
			fit: 1,
			form: 0
		},
		context: ["Harris holds the ranking and a bigger serve. Uchida is at home."]
	},
	{
		id: "mat-noguchi-daniel",
		event: "Ehime International",
		place: "Matsuyama",
		category: 75,
		surface: "hard-outdoor",
		round: "Quarter-final",
		a: {
			name: "Rio Noguchi",
			country: "JPN",
			rank: 233,
			serve: 0,
			fit: 1,
			form: 1,
			home: true
		},
		b: {
			name: "Taro Daniel",
			country: "JPN",
			rank: 172,
			serve: 0,
			fit: 1,
			form: 0
		},
		context: ["Both Japanese. Daniel is the higher rank; Noguchi has the crowd."]
	},
	{
		id: "mat-hsu-friend",
		event: "Ehime International",
		place: "Matsuyama",
		category: 75,
		surface: "hard-outdoor",
		round: "Quarter-final",
		a: {
			name: "Yu-hsiou Hsu",
			country: "TPE",
			rank: 312,
			serve: 0,
			fit: 1,
			form: 0
		},
		b: {
			name: "Jay Dylan Hara Friend",
			country: "JPN",
			rank: 256,
			serve: 0,
			fit: 1,
			form: 0,
			home: true
		},
		context: ["A short ranking gap and a home player on the lower-ranked side of it."]
	},
	{
		id: "bri-sweeny-shang",
		event: "Brisbane QTC #3",
		place: "Brisbane",
		category: 75,
		surface: "hard-outdoor",
		round: "Quarter-final",
		a: {
			name: "Dane Sweeny",
			country: "AUS",
			rank: 116,
			serve: 0,
			fit: 2,
			form: 1,
			home: true
		},
		b: {
			name: "Juncheng Shang",
			country: "CHN",
			rank: 252,
			serve: 1,
			fit: 1,
			form: 1,
			live: true
		},
		context: ["Sweeny is a top-120 home player. Shang still has the weapons to nick a set."]
	},
	{
		id: "bri-santillan-langmo",
		event: "Brisbane QTC #3",
		place: "Brisbane",
		category: 75,
		surface: "hard-outdoor",
		round: "Quarter-final",
		a: {
			name: "Akira Santillan",
			country: "AUS",
			rank: 349,
			serve: 0,
			fit: 1,
			form: 1,
			home: true
		},
		b: {
			name: "Christian Langmo",
			country: "USA",
			rank: 528,
			serve: 0,
			fit: 0,
			form: 0
		},
		context: ["Home underdog in rank only relative to the cut. Langmo is well outside the top 500."]
	},
	{
		id: "bri-bolt-gorzny",
		event: "Brisbane QTC #3",
		place: "Brisbane",
		category: 75,
		surface: "hard-outdoor",
		round: "Quarter-final",
		a: {
			name: "Alex Bolt",
			country: "AUS",
			rank: 171,
			serve: 1,
			fit: 2,
			form: 1,
			home: true
		},
		b: {
			name: "Sebastian Gorzny",
			country: "USA",
			rank: 403,
			serve: 1,
			fit: 0,
			form: 0
		},
		context: ["Bolt at home with the serve and the ranking. Pairing is the published quarter-final slot."]
	},
	{
		id: "bri-tomic-holmgren",
		event: "Brisbane QTC #3",
		place: "Brisbane",
		category: 75,
		surface: "hard-outdoor",
		round: "Quarter-final",
		a: {
			name: "Bernard Tomic",
			country: "AUS",
			rank: 176,
			serve: 2,
			fit: 1,
			form: 0,
			home: true,
			leaky: true
		},
		b: {
			name: "August Holmgren",
			country: "DEN",
			rank: 265,
			serve: 0,
			fit: 1,
			form: 0
		},
		context: ["Tomic's serve wins matches and also donates sets. Holmgren is close enough in rank to collect one."]
	},
	{
		id: "her-maestrelli-nagal",
		event: "Hersonissos 3",
		place: "Hersonissos",
		category: 50,
		surface: "hard-outdoor",
		round: "Quarter-final",
		a: {
			name: "Francesco Maestrelli",
			country: "ITA",
			rank: 168,
			serve: 0,
			fit: 0,
			form: 1
		},
		b: {
			name: "Sumit Nagal",
			country: "IND",
			rank: 264,
			serve: 0,
			fit: -1,
			form: 0
		},
		context: ["Challenger 50. Maestrelli is the rank. Nagal is a clay lean on outdoor hard, which cuts his price."]
	},
	{
		id: "her-carboni-henning",
		event: "Hersonissos 3",
		place: "Hersonissos",
		category: 50,
		surface: "hard-outdoor",
		round: "Quarter-final",
		a: {
			name: "Lorenzo Carboni",
			country: "ITA",
			rank: 550,
			serve: -1,
			fit: 0,
			form: 0
		},
		b: {
			name: "Philip Henning",
			country: "RSA",
			rank: 249,
			serve: 0,
			fit: 1,
			form: 1
		},
		context: ["Henning is more than 300 places higher. Challenger 50 still taxes a straight-sets claim."]
	},
	{
		id: "her-ribecai-andreev",
		event: "Hersonissos 3",
		place: "Hersonissos",
		category: 50,
		surface: "hard-outdoor",
		round: "Quarter-final",
		a: {
			name: "Michele Ribecai",
			country: "ITA",
			rank: 281,
			serve: 0,
			fit: 1,
			form: 1
		},
		b: {
			name: "Adrian Andreev",
			country: "BUL",
			rank: 584,
			serve: -1,
			fit: 0,
			form: 0
		},
		context: ["Ribecai against a player outside the top 580. The level is Challenger 50, so the bar for 2–0 is higher."]
	},
	{
		id: "her-giunta-searle",
		event: "Hersonissos 3",
		place: "Hersonissos",
		category: 50,
		surface: "hard-outdoor",
		round: "Quarter-final",
		a: {
			name: "Massimo Giunta",
			country: "ITA",
			rank: 369,
			serve: 0,
			fit: 0,
			form: 0
		},
		b: {
			name: "Henry Searle",
			country: "GBR",
			rank: 231,
			serve: 1,
			fit: 1,
			form: 1
		},
		context: ["Searle is the younger, higher-ranked player with a serve. Giunta is not a noted set-stealer."]
	},
	{
		id: "mon-forejtek-mikrut",
		event: "Monastir Open",
		place: "Monastir",
		category: 50,
		surface: "hard-outdoor",
		round: "Quarter-final",
		a: {
			name: "Jonáš Forejtek",
			country: "CZE",
			rank: 303,
			serve: 0,
			fit: 0,
			form: 0
		},
		b: {
			name: "Luka Mikrut",
			country: "CRO",
			rank: 255,
			serve: 1,
			fit: 1,
			form: 1
		},
		context: ["Short gap at Challenger 50. Mikrut is the higher rank."]
	},
	{
		id: "mon-moller-giustino",
		event: "Monastir Open",
		place: "Monastir",
		category: 50,
		surface: "hard-outdoor",
		round: "Quarter-final",
		a: {
			name: "Elmer Møller",
			country: "DEN",
			rank: 148,
			serve: 0,
			fit: 1,
			form: 1
		},
		b: {
			name: "Lorenzo Giustino",
			country: "ITA",
			rank: 289,
			serve: 0,
			fit: 0,
			form: 0,
			live: true
		},
		context: ["Møller is the clear rank. Giustino is a veteran who still takes a set rather than a match."]
	},
	{
		id: "mon-vives-moro",
		event: "Monastir Open",
		place: "Monastir",
		category: 50,
		surface: "hard-outdoor",
		round: "Quarter-final",
		a: {
			name: "Pedro Vives Marcos",
			country: "ESP",
			rank: 585,
			serve: -1,
			fit: 0,
			form: 0
		},
		b: {
			name: "Alejandro Moro Cañas",
			country: "ESP",
			rank: 242,
			serve: 0,
			fit: 1,
			form: 1
		},
		context: ["Moro Cañas is the rank by a long way. Same nation, outdoor hard, Challenger 50."]
	},
	{
		id: "mon-feldbausch-petkovic",
		event: "Monastir Open",
		place: "Monastir",
		category: 50,
		surface: "hard-outdoor",
		round: "Quarter-final",
		a: {
			name: "Kilian Feldbausch",
			country: "SUI",
			rank: 238,
			serve: 0,
			fit: 1,
			form: 1
		},
		b: {
			name: "Mika Petkovic",
			country: "GER",
			rank: 389,
			serve: 0,
			fit: 0,
			form: 0
		},
		context: ["Feldbausch reached the Taranto final last week and lost it in straights. Petkovic is the rank dog."]
	}
];
function priceBoard(matches = BOARD) {
	return matches.map((match) => {
		const line = price(match);
		return {
			match,
			line,
			ticket: decide(match, line)
		};
	});
}
var PRICED = priceBoard();
var VIEWS = [
	{
		id: "straight",
		label: "Favourites 2–0"
	},
	{
		id: "set",
		label: "Win a set 2–1"
	},
	{
		id: "board",
		label: "Full board"
	},
	{
		id: "model",
		label: "The model"
	}
];
function pct(n) {
	return `${Math.round(n * 100)}%`;
}
function lastName(name) {
	return name.split(" ").slice(-1)[0] ?? name;
}
function surfaceWord(s) {
	if (s === "hard-indoor") return "Indoor hard";
	if (s === "hard-outdoor") return "Outdoor hard";
	return "Clay";
}
function favouriteSide(line) {
	return line.matchA >= .5 ? "a" : "b";
}
function Desk() {
	const [view, setView] = (0, import_react.useState)("straight");
	const [event, setEvent] = (0, import_react.useState)("All");
	const events = (0, import_react.useMemo)(() => ["All", ...new Set(PRICED.map((p) => p.match.event))], []);
	const counts = (0, import_react.useMemo)(() => ({
		straight: PRICED.filter((p) => p.ticket.kind === "straight").length,
		set: PRICED.filter((p) => p.ticket.kind === "set").length,
		pass: PRICED.filter((p) => p.ticket.kind === "pass").length
	}), []);
	const rows = PRICED.filter((p) => event === "All" || p.match.event === event).filter((p) => {
		if (view === "straight") return p.ticket.kind === "straight";
		if (view === "set") return p.ticket.kind === "set";
		if (view === "board") return true;
		return false;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto w-full max-w-5xl px-4 pt-8 pb-16 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "border-b border-border pb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-[0.18em] text-primary uppercase",
						children: "ATP Challenger · Friday 13 Nov 2026"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display mt-2 text-5xl leading-none font-medium tracking-tight sm:text-6xl",
						children: "Two-Nil"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-base text-muted",
						children: "A set-line desk, not a winner dump. A favourite is printed only when the score is 2–0. A player to win at least one set is printed only as a 2–1."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-6 grid grid-cols-3 gap-2 sm:max-w-md",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "Straight sets",
								v: String(counts.straight)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "Win a set",
								v: String(counts.set)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "Passed",
								v: String(counts.pass)
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid grid-cols-2 gap-2 sm:grid-cols-4",
				role: "tablist",
				"aria-label": "Board",
				children: VIEWS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "tab",
					"aria-selected": view === item.id,
					onClick: () => setView(item.id),
					className: "min-h-11 rounded-full border px-3 text-sm font-medium transition-colors " + (view === item.id ? "border-primary bg-primary text-bg" : "border-border bg-surface text-fg hover:border-muted"),
					children: item.label
				}, item.id))
			}),
			view !== "model" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex gap-2 overflow-x-auto pb-1",
				children: events.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setEvent(name),
					className: "min-h-11 shrink-0 rounded-full border px-3 text-sm " + (event === name ? "border-fg bg-raised text-fg" : "border-border text-muted hover:text-fg"),
					children: name === "All" ? "All events" : name
				}, name))
			}),
			view === "model" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModelLab, {}) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 text-muted",
				children: "Nothing in this draw clears the rule. The desk passed it."
			}) : view === "board" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 flex flex-col gap-2",
				children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoardRow, { row }, row.match.id))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 flex flex-col gap-4",
				children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TicketCard, { row }, row.match.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mt-12 border-t border-border pt-6 text-sm text-faint",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Draws and seeds from the ATP Challenger Tour. Order of play from Flashscore and SofaScore. Ranks are the ATP singles list, week of 9 November 2026. Prices are pre-match — once a match is on court, the ticket is void." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2",
					children: "This is a probability model for the set-line. It is not a bookmaker, and it is not a promise."
				})]
			})
		]
	});
}
function Stat({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-card border border-border bg-surface px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-faint",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "font-display text-3xl leading-none",
			children: v
		})]
	});
}
function metaLine(match) {
	const bits = [
		match.place,
		surfaceWord(match.surface),
		`Challenger ${match.category}`,
		match.round
	];
	if (match.when) bits.push(`${match.when} local`);
	return bits.join(" · ");
}
function playerBits(p) {
	const bits = [p.rank == null ? "Unranked" : `No. ${p.rank}`, p.country];
	if (p.tag) bits.push(p.tag);
	if (p.home) bits.push("Home");
	return bits.join(" · ");
}
function TicketCard({ row }) {
	const { match, line, ticket } = row;
	const [open, setOpen] = (0, import_react.useState)(false);
	if (!line || !ticket.pick || !ticket.score) return null;
	const pick = ticket.pick === "a" ? match.a : match.b;
	const other = ticket.pick === "a" ? match.b : match.a;
	const fav = favouriteSide(line) === "a" ? match.a : match.b;
	const headline = ticket.kind === "straight" ? `${pick.name} in straight sets` : `${pick.name} wins at least one set`;
	const script = ticket.kind === "straight" ? `Only score printed: 2–0 over ${other.name}` : `${fav.name} wins the match 2–1. ${pick.name} takes the set.`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "rounded-card border border-border bg-surface p-4 sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-[0.16em] text-primary uppercase",
					children: ticket.kind === "straight" ? "Pure favourite" : "At least one set"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-display text-2xl leading-none text-primary",
					children: ticket.score === "2-0" ? "2–0" : "2–1"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display mt-3 text-3xl leading-tight font-medium",
				children: headline
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: script
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs tracking-wide text-faint uppercase",
				children: metaLine(match)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-2 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerChip, {
					player: match.a,
					mark: ticket.pick === "a",
					side: "A"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerChip, {
					player: match.b,
					mark: ticket.pick === "b",
					side: "B"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bars, {
					line,
					emphasize: ticket.score,
					favIsA: favouriteSide(line) === "a"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-fg",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: "Price "
					}),
					pct(ticket.confidence),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: ticket.kind === "straight" ? " straight sets" : " to win a set"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mt-3 min-h-11 text-sm font-medium text-primary",
				"aria-expanded": open,
				onClick: () => setOpen((v) => !v),
				children: open ? "Hide the price" : "Why this score"
			}),
			open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 border-t border-border pt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-fg",
					children: ticket.reason
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-2 flex flex-col gap-1 text-sm text-muted",
					children: ticket.bullets.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: b }, b))
				})]
			})
		]
	});
}
function PlayerChip({ player, mark, side }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border px-3 py-3 " + (mark ? "border-primary bg-raised" : "border-border"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-faint",
				children: side
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-medium text-fg",
				children: player.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: playerBits(player)
			})
		]
	});
}
function Bars({ line, emphasize, favIsA }) {
	const rows = favIsA ? [
		{
			id: "2-0",
			label: "2–0",
			v: line.a20
		},
		{
			id: "2-1",
			label: "2–1",
			v: line.a21
		},
		{
			id: "1-2",
			label: "1–2",
			v: line.b21
		},
		{
			id: "0-2",
			label: "0–2",
			v: line.b02
		}
	] : [
		{
			id: "2-0",
			label: "2–0",
			v: line.b02
		},
		{
			id: "2-1",
			label: "2–1",
			v: line.b21
		},
		{
			id: "1-2",
			label: "1–2",
			v: line.a21
		},
		{
			id: "0-2",
			label: "0–2",
			v: line.a20
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-col gap-1.5",
		"aria-hidden": "true",
		children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-[2.5rem_1fr_2.5rem] items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs " + (emphasize === row.id ? "text-primary" : "text-faint"),
					children: row.label
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "h-1.5 overflow-hidden rounded-full bg-raised",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block h-full rounded-full " + (emphasize === row.id ? "bg-primary" : "bg-faint"),
						style: { width: `${Math.max(2, Math.round(row.v * 100))}%` }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-right text-xs text-muted tabular-nums",
					children: pct(row.v)
				})
			]
		}, row.label + row.id))
	});
}
function BoardRow({ row }) {
	const { match, ticket, line } = row;
	const [open, setOpen] = (0, import_react.useState)(false);
	const pill = ticket.kind === "straight" ? "2–0" : ticket.kind === "set" ? "2–1" : "Pass";
	const who = ticket.pick == null ? ticket.reason : ticket.pick === "a" ? match.a.name : match.b.name;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "rounded-card border border-border bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "flex min-h-11 w-full items-center gap-3 px-4 py-3 text-left",
			"aria-expanded": open,
			onClick: () => setOpen((v) => !v),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-12 shrink-0 text-sm font-medium " + (ticket.kind === "pass" ? "text-faint" : "text-primary"),
				children: pill
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "block truncate text-sm text-fg",
					children: [
						lastName(match.a.name),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-faint",
							children: " vs "
						}),
						lastName(match.b.name)
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "block truncate text-xs text-muted",
					children: [
						match.place,
						" · ",
						who
					]
				})]
			})]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-t border-border px-4 py-3",
			children: [line && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bars, {
				line,
				emphasize: ticket.score,
				favIsA: line.matchA >= .5
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: ticket.reason
			})]
		})]
	});
}
function blankPlayer(name) {
	return {
		name,
		country: "—",
		rank: 100,
		serve: 0,
		fit: 0,
		form: 0
	};
}
function ModelLab() {
	const [rankA, setRankA] = (0, import_react.useState)(80);
	const [rankB, setRankB] = (0, import_react.useState)(220);
	const [surface, setSurface] = (0, import_react.useState)("hard-indoor");
	const [category, setCategory] = (0, import_react.useState)(125);
	const [serveA, setServeA] = (0, import_react.useState)(0);
	const [serveB, setServeB] = (0, import_react.useState)(0);
	const [liveB, setLiveB] = (0, import_react.useState)(false);
	const [leakyA, setLeakyA] = (0, import_react.useState)(false);
	const built = (0, import_react.useMemo)(() => {
		const match = {
			id: "lab",
			event: "Model lab",
			place: "Anywhere",
			category,
			surface,
			round: "Best of 3",
			a: {
				...blankPlayer("Player A"),
				rank: Math.max(1, rankA),
				serve: serveA,
				leaky: leakyA
			},
			b: {
				...blankPlayer("Player B"),
				rank: Math.max(1, rankB),
				serve: serveB,
				live: liveB
			},
			context: ["Lab match. Same point, game, set and ticket rules as the board."]
		};
		const line = price(match);
		return {
			match,
			line,
			ticket: decide(match, line)
		};
	}, [
		rankA,
		rankB,
		surface,
		category,
		serveA,
		serveB,
		liveB,
		leakyA
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl font-medium",
				children: "How a ticket gets printed"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "mt-4 grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, {
						n: "1",
						title: "Rank into a rating",
						children: "ATP rank becomes a log rating. Surface fit, form, serve and home court can nudge it, and that nudge is capped so a hot week cannot erase a real ranking gap."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, {
						n: "2",
						title: "Points on serve",
						children: "Each player’s serve-point chance comes from the surface base plus the rating gap. Indoor hard starts higher than clay. Challenger 50 compresses the gap."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, {
						n: "3",
						title: "Game, set, match",
						children: "Advantage games, a first-to-six set with a tiebreak at 6–6, best of three. Who serves first is averaged. Sets are treated as independent once the serve points are fixed."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, {
						n: "4",
						title: "Two markets, never both",
						children: "Pure favourite: match price and straight sets both clear the bar, the ranking gap is wide, and nothing about form or serve says the underdog steals a set. Otherwise, if the underdog is live, the only other ticket is that player to win a set in a 2–1."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 rounded-card border border-border bg-surface p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-2xl font-medium",
						children: "Run a match"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-4 sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankField, {
								label: "Player A rank",
								value: rankA,
								onChange: setRankA
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankField, {
								label: "Player B rank",
								value: rankB,
								onChange: setRankB
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex flex-col gap-1 text-sm text-muted",
								children: ["Surface", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "min-h-11 rounded-xl border border-border bg-bg px-3 text-base text-fg",
									value: surface,
									onChange: (e) => setSurface(e.target.value),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "hard-indoor",
											children: "Indoor hard"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "hard-outdoor",
											children: "Outdoor hard"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "clay",
											children: "Clay"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex flex-col gap-1 text-sm text-muted",
								children: ["Level", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "min-h-11 rounded-xl border border-border bg-bg px-3 text-base text-fg",
									value: category,
									onChange: (e) => setCategory(Number(e.target.value)),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: 125,
											children: "Challenger 125"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: 75,
											children: "Challenger 75"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: 50,
											children: "Challenger 50"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServeField, {
								label: "A serve",
								value: serveA,
								onChange: setServeA
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServeField, {
								label: "B serve",
								value: serveB,
								onChange: setServeB
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: liveB,
							label: "B takes sets off better players",
							onClick: () => setLiveB((v) => !v)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
							on: leakyA,
							label: "A has been going three",
							onClick: () => setLeakyA((v) => !v)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabResult, {
						ticket: built.ticket,
						line: built.line
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm text-muted",
				children: "For any real set favourite, 2–0 is the single most likely score under independent sets. That is why a favourite ticket is only issued when straight sets is also likely in absolute terms. The set ticket is a different market: the match is not pure, the underdog wins one set, and the score we will write down is 2–1."
			})
		]
	});
}
function Step({ n, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "rounded-card border border-border bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-primary",
				children: ["0", n]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-1 font-medium text-fg",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children
			})
		]
	});
}
function RankField({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex flex-col gap-1 text-sm text-muted",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "number",
			min: 1,
			max: 2e3,
			value,
			onChange: (e) => onChange(Number(e.target.value) || 1),
			className: "min-h-11 rounded-xl border border-border bg-bg px-3 text-base text-fg"
		})]
	});
}
function ServeField({ label, value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-1 grid grid-cols-4 gap-1",
		children: [
			-1,
			0,
			1,
			2
		].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => onChange(n),
			className: "min-h-11 rounded-xl border text-sm " + (value === n ? "border-primary bg-primary text-bg" : "border-border text-fg"),
			children: n > 0 ? `+${n}` : n
		}, n))
	})] });
}
function Toggle({ on, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": on,
		onClick,
		className: "min-h-11 rounded-full border px-3 text-sm " + (on ? "border-primary text-primary" : "border-border text-muted"),
		children: label
	});
}
function LabResult({ ticket, line }) {
	if (!line) return null;
	const fav = line.matchA >= .5 ? "A" : "B";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-5 border-t border-border pt-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-[0.16em] text-primary uppercase",
				children: ticket.kind === "straight" ? "Ticket · 2–0" : ticket.kind === "set" ? "Ticket · 2–1" : "No ticket"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-fg",
				children: ticket.reason
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [
					"Favourite ",
					fav,
					" · match ",
					pct(Math.max(line.matchA, 1 - line.matchA)),
					" · serve points",
					" ",
					pct(line.spwA),
					" / ",
					pct(line.spwB)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bars, {
					line,
					emphasize: ticket.score,
					favIsA: line.matchA >= .5
				})
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Desk, {});
}
//#endregion
export { Home as component };
