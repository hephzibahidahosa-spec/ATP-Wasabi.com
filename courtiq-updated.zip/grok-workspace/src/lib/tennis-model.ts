/** Best-of-3 set-line model for ATP Challenger.
 *
 * Point → game → set → match. Sets are treated as i.i.d. given the two
 * players' points-on-serve. For any set favourite the single most likely
 * score is 2–0; a straight-sets ticket is printed only when that score is
 * also likely in absolute terms and the favourite is "pure". The other
 * ticket is a different market: the underdog wins a set, and the only
 * scoreline attached to it is 2–1.
 */

export type Surface = "hard-indoor" | "hard-outdoor" | "clay";

export type PlayerInput = {
  name: string;
  country: string;
  /** Official ATP rank. Null when the player is not on the published list. */
  rank: number | null;
  tag?: string;
  /** Serve quality, -1 weak to +2 heavy. */
  serve: number;
  /** Fit to this match's surface, -2 to +2. */
  fit: number;
  /** Recent form, -2 to +2. */
  form: number;
  home?: boolean;
  /** Has been taken to three sets, or habitually fails to close. */
  leaky?: boolean;
  /** Takes sets off better players. Blocks a pure 2–0 against them. */
  live?: boolean;
};

export type MatchInput = {
  id: string;
  event: string;
  place: string;
  category: 125 | 75 | 50;
  surface: Surface;
  round: string;
  when?: string;
  a: PlayerInput;
  b: PlayerInput;
  context: string[];
};

export type Scoreline = {
  /** P(A wins 2–0), P(A wins 2–1), P(B wins 2–1), P(B wins 2–0). */
  a20: number;
  a21: number;
  b21: number;
  b02: number;
  setA: number;
  matchA: number;
  spwA: number;
  spwB: number;
  holdA: number;
  holdB: number;
};

export type TicketKind = "straight" | "set" | "pass";

export type Ticket = {
  kind: TicketKind;
  /** Player the ticket is on. Null on a pass. */
  pick: "a" | "b" | null;
  /** Scoreline we are willing to print. */
  score: "2-0" | "2-1" | null;
  /** Model confidence in the printed market. */
  confidence: number;
  reason: string;
  bullets: string[];
};

const BASE_SPW: Record<Surface, number> = {
  "hard-indoor": 0.632,
  "hard-outdoor": 0.62,
  clay: 0.598,
};

function clamp(n: number, lo: number, hi: number) {
  return Math.min(hi, Math.max(lo, n));
}

export function playerRating(p: PlayerInput): number | null {
  if (p.rank == null || p.rank < 1) return null;
  const base = 1580 - 96 * Math.log(p.rank);
  const adj = clamp(
    p.fit * 12 + p.form * 8 + p.serve * 4 + (p.home ? 10 : 0) + (p.leaky ? -6 : 0) + (p.live ? 4 : 0),
    -28,
    22,
  );
  return base + adj;
}

function gapScale(category: MatchInput["category"]) {
  if (category === 50) return 0.78;
  if (category === 75) return 0.9;
  return 1;
}

export function servePoints(
  server: PlayerInput,
  returner: PlayerInput,
  surface: Surface,
  category: MatchInput["category"],
): number | null {
  const rs = playerRating(server);
  const rr = playerRating(returner);
  if (rs == null || rr == null) return null;
  const diff = ((rs - rr) / 100) * gapScale(category);
  let spw = BASE_SPW[surface] + 0.042 * diff;
  spw += 0.008 * server.serve;
  spw -= 0.004 * returner.serve;
  if (server.leaky) spw -= 0.006;
  if (returner.live) spw -= 0.004;
  return clamp(spw, 0.5, 0.74);
}

/** P(server wins a game) under advantage scoring. */
export function gameWinProb(p: number): number {
  const q = 1 - p;
  const deuce = (p * p) / (p * p + q * q);
  return p ** 4 * (1 + 4 * q + 10 * q * q) + 20 * p ** 3 * q ** 3 * deuce;
}

function tbServerIsA(pointIndex: number, aStarts: boolean): boolean {
  let aServes: boolean;
  if (pointIndex === 0) aServes = true;
  else aServes = Math.floor((pointIndex - 1) / 2) % 2 === 1;
  return aStarts ? aServes : !aServes;
}

/** P(A wins a tiebreak), first to 7 win by 2. Deterministic DP. */
export function tiebreakWin(spwA: number, spwB: number, aStarts: boolean): number {
  const MAX = 24;
  const dp: number[][] = Array.from({ length: MAX + 1 }, () => Array(MAX + 1).fill(0));
  for (let a = MAX; a >= 0; a--) {
    for (let b = MAX; b >= 0; b--) {
      if (a >= 7 && a >= b + 2) {
        dp[a]![b] = 1;
        continue;
      }
      if (b >= 7 && b >= a + 2) {
        dp[a]![b] = 0;
        continue;
      }
      if (a === MAX || b === MAX) {
        dp[a]![b] = a === b ? 0.5 : a > b ? 0.85 : 0.15;
        continue;
      }
      const aServes = tbServerIsA(a + b, aStarts);
      const p = aServes ? spwA : 1 - spwB;
      dp[a]![b] = p * dp[a + 1]![b]! + (1 - p) * dp[a]![b + 1]!;
    }
  }
  return dp[0]![0]!;
}

/** P(A wins a set), averaging who serves first. */
export function setWinProb(spwA: number, spwB: number): number {
  const holdA = gameWinProb(spwA);
  const breakA = 1 - gameWinProb(spwB);
  const once = (aServesFirst: boolean) => {
    const memo = new Map<string, number>();
    const p = (a: number, b: number): number => {
      const key = `${a}-${b}`;
      const hit = memo.get(key);
      if (hit != null) return hit;
      let val: number;
      if (a >= 6 && a - b >= 2) val = 1;
      else if (b >= 6 && b - a >= 2) val = 0;
      else if (a === 6 && b === 6) val = tiebreakWin(spwA, spwB, aServesFirst);
      else {
        const aServes = aServesFirst ? (a + b) % 2 === 0 : (a + b) % 2 === 1;
        const winGame = aServes ? holdA : breakA;
        val = winGame * p(a + 1, b) + (1 - winGame) * p(a, b + 1);
      }
      memo.set(key, val);
      return val;
    };
    return p(0, 0);
  };
  return 0.5 * (once(true) + once(false));
}

export function scoreMatch(
  spwA: number,
  spwB: number,
): Omit<Scoreline, "spwA" | "spwB" | "holdA" | "holdB"> & { setA: number; matchA: number } {
  const s = setWinProb(spwA, spwB);
  const a20 = s * s;
  const a21 = 2 * s * s * (1 - s);
  const b21 = 2 * (1 - s) * (1 - s) * s;
  const b02 = (1 - s) * (1 - s);
  return { a20, a21, b21, b02, setA: s, matchA: a20 + a21 };
}

export function price(match: MatchInput): Scoreline | null {
  const spwA = servePoints(match.a, match.b, match.surface, match.category);
  const spwB = servePoints(match.b, match.a, match.surface, match.category);
  if (spwA == null || spwB == null) return null;
  const scored = scoreMatch(spwA, spwB);
  return {
    ...scored,
    spwA,
    spwB,
    holdA: gameWinProb(spwA),
    holdB: gameWinProb(spwB),
  };
}

function pct(n: number) {
  return `${Math.round(n * 100)}%`;
}

function surfaceLabel(s: Surface) {
  if (s === "hard-indoor") return "indoor hard";
  if (s === "hard-outdoor") return "outdoor hard";
  return "clay";
}

export function decide(match: MatchInput, line: Scoreline | null): Ticket {
  if (line == null || match.a.rank == null || match.b.rank == null) {
    return {
      kind: "pass",
      pick: null,
      score: null,
      confidence: 0,
      reason: "One player is off the published ATP ranking list, so the price is not a ticket.",
      bullets: [
        "No invented rank is used to manufacture a favourite.",
        "Straight-sets and set tickets both stay blank.",
      ],
    };
  }

  const fav: "a" | "b" = line.matchA >= 0.5 ? "a" : "b";
  const dog: "a" | "b" = fav === "a" ? "b" : "a";
  const favP = fav === "a" ? match.a : match.b;
  const dogP = dog === "a" ? match.a : match.b;
  const setFav = fav === "a" ? line.setA : 1 - line.setA;
  const matchFav = setFav * setFav * (3 - 2 * setFav);
  const p20 = setFav * setFav;
  const p21 = 2 * setFav * setFav * (1 - setFav);
  const dogSet = 1 - setFav;
  const dogAtLeast = 1 - p20;

  const lowLevel = match.category === 50;
  const p20Cut = lowLevel ? 0.5 : 0.47;
  const matchCut = lowLevel ? 0.76 : 0.72;
  const marginCut = 0.1;
  const rankRatio =
    dogP.rank != null && favP.rank != null ? dogP.rank / favP.rank : 1;
  const rankGapOk = rankRatio >= 1.85;

  const blocks: string[] = [];
  if (favP.leaky) blocks.push(`${favP.name.split(" ").slice(-1)[0]} has been extended to three`);
  if (dogP.live) blocks.push(`${dogP.name.split(" ").slice(-1)[0]} takes sets off better players`);
  if (dogP.serve >= 2) blocks.push(`${dogP.name.split(" ").slice(-1)[0]} has a serve that steals sets`);
  if (dogP.form >= 2) blocks.push(`${dogP.name.split(" ").slice(-1)[0]} is in the kind of form that makes 2–0 fragile`);

  const pure =
    blocks.length === 0 &&
    rankGapOk &&
    matchFav >= matchCut &&
    p20 >= p20Cut &&
    p20 >= p21 + marginCut;

  const last = (p: PlayerInput) => p.name.split(" ").slice(-1)[0] ?? p.name;

  const shared = [
    `${last(match.a)} No. ${match.a.rank} vs ${last(match.b)} No. ${match.b.rank} on ${surfaceLabel(match.surface)}.`,
    `Serve points ${pct(line.spwA)} / ${pct(line.spwB)}. Holds ${pct(line.holdA)} / ${pct(line.holdB)}. Set ${pct(line.setA)} for ${last(match.a)}.`,
  ];

  if (pure) {
    return {
      kind: "straight",
      pick: fav,
      score: "2-0",
      confidence: p20,
      reason: `${favP.name} is a pure favourite. The only score printed is 2–0.`,
      bullets: [
        ...shared,
        `Match ${pct(matchFav)}, straight sets ${pct(p20)} against ${pct(p21)} for 2–1. Gap clears the ${match.category === 50 ? "Challenger 50" : "Challenger"} bar.`,
        match.context[0] ?? "No extra veto from form, serve or a live underdog.",
      ],
    };
  }

  const setOk =
    matchFav >= 0.63 &&
    matchFav < 0.76 &&
    dogAtLeast >= 0.55 &&
    dogSet >= 0.38 &&
    p21 + 0.02 >= p20 * 0.45;
  // A live dog, a leaky favourite or a big underdog serve blocks 2–0.
  // That block is itself the set ticket, as long as the dog can actually win one.
  const vetoRedirect =
    blocks.length > 0 && matchFav >= 0.6 && matchFav <= 0.84 && dogAtLeast >= 0.48 && dogSet >= 0.27;

  if (setOk || vetoRedirect) {
    return {
      kind: "set",
      pick: dog,
      score: "2-1",
      confidence: dogAtLeast,
      reason: `${dogP.name} to win at least one set. The match is scripted 2–1, not a straight-sets favourite.`,
      bullets: [
        ...shared,
        `${last(favP)} is favoured at ${pct(matchFav)} but straight sets is only ${pct(p20)} — not pure. ${last(dogP)} wins a set ${pct(dogAtLeast)} of the time.`,
        blocks[0] ??
          match.context[0] ??
          "Close enough that a stolen set is the price, and the match still has a winner.",
      ],
    };
  }

  let reason = "No ticket. Neither a pure 2–0 favourite nor a live 2–1 set.";
  if (matchFav < 0.6) reason = "Toss-up. No favourite is pure, and a 2–1 script needs a side.";
  else if (!rankGapOk && blocks.length === 0 && p20 >= p20Cut && matchFav >= matchCut) {
    reason = "The score leans 2–0, but the ranking gap is too short to call anyone a pure favourite.";
  } else if (blocks.length && p20 >= p20Cut) {
    reason = `Straight sets is the lean, but it is not pure: ${blocks[0]}. The underdog's set price is still too thin to buy.`;
  } else if (dogAtLeast < 0.56) {
    reason = "The underdog is not live enough to buy a set, and the favourite is not pure enough for 2–0.";
  }

  return {
    kind: "pass",
    pick: null,
    score: null,
    confidence: 0,
    reason,
    bullets: [...shared, blocks[0] ?? "Left on the board."],
  };
}
